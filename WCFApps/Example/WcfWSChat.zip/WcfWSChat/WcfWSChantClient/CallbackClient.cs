﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WcfWSChantClient
{
    using WSChatServiceReference;

    class CallbackClient : IWSChatServiceCallback
    {
        public void SendMessageToClient(string msg)
        {
            Console.WriteLine(msg);
        }
    }
}
