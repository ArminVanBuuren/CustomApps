﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace WcfWSChantClient
{
    using System.Threading;
    using WSChatServiceReference;

    class Program
    {
        static void Main(string[] args)
        {
            var context = new InstanceContext(new CallbackClient());
            var client = new WSChatServiceClient(context);

            while (true)
            {
                Console.Write("Input (\"Exit\" to exit):");
                string input = Console.ReadLine();
                if (input.ToUpperInvariant() == "EXIT")
                {
                    break;
                }

                client.SendMessageToServer(input);
                Thread.Sleep(500);
            }

            client.Close();
        }
    }
}
